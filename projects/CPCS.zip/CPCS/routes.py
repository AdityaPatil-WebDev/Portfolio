from flask import Blueprint, render_template, request, redirect, session, jsonify, url_for
from flask_mysqldb import MySQL
import MySQLdb.cursors
import os
import pdfplumber,tempfile
import openpyxl
from sqlalchemy.exc import IntegrityError
import random
import string
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from extensions import db, mysql
from models import Meeting, Announcement, Grievance
from models import db, HOD, TeachingStaff, NonTeachingStaff, Student, Principal
from werkzeug.utils import secure_filename
from flask import current_app
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
MAX_FILE_SIZE_MB = 2

# Blueprint instances
routes = Blueprint('routes', __name__)
announcement_bp = Blueprint('announcement', __name__)
settings_bp = Blueprint('settings', __name__)
meeting_bp = Blueprint("meeting", __name__)
grievance_bp=Blueprint("grievance", __name__)
admin_bp= Blueprint('admin_bp', __name__)


# Utility Functions
def generate_random_password(length=8):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# Routes
@routes.route('/')
def home():
    return render_template('index.html')

@routes.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_id = request.form.get('login_id')  # Either email or roll_number
        password = request.form.get('password')
        role = request.form.get('role')

        if not role:
            return render_template('login.html', message="Please select a role before logging in!", status="error")

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        table, name_field, lookup_field = None, "full_name", "email"

        # Map roles to table and field details
        role_table_map = {
            "Principal": ("principal", "name", "email"),
            "HOD": ("hod", "full_name", "email"),
            "Teaching Staff": ("teaching_staff", "full_name", "email"),
            "Non-Teaching Staff": ("non_teachingstaff", "full_name", "email"),
            "Student": ("student", "full_name", "roll_number")
        }

        if role in role_table_map:
            table, name_field, lookup_field = role_table_map[role]
        else:
            return render_template('login.html', message="Invalid role selected!", status="error")

        # Query the database
        cursor.execute(f"SELECT * FROM {table} WHERE {lookup_field}=%s", (login_id,))
        user = cursor.fetchone()
        cursor.close()

        # Redirect URLs
        dashboard_routes = {
            "Principal": "/principal_dashboard",
            "HOD": "/hod_dashboard",
            "Teaching Staff": "/teaching_staff_dashboard",
            "Non-Teaching Staff": "/non_teaching_dashboard",
            "Student": "/student_dashboard"
        }

        if user and check_password_hash(user['password_hash'], password):
            session.clear()  # Clear previous session for safety
            session['loggedin'] = True
            session['name'] = user[name_field]
            session['role'] = role
            session['user_id'] = login_id

    # Set email for all roles except students (who use roll_number as ID but still have email)
            session['email'] = user.get('email') if 'email' in user else None

            if role == "Student":
                session['full_name'] = user.get('full_name')
                session['roll_number'] = user.get('roll_number')

            if 'department' in user:
                session['department'] = user['department']
            
            session['profile_photo'] = user.get('profile_photo', 'default.png')


    # Confirm sessions are set
            print("SESSION SET:", session)

            return render_template(
                'login.html',
                message="Login successful! Redirecting...",
                status="success",
                redirect_url=dashboard_routes[role]
            )

        return render_template('login.html', message="Invalid credentials. Please try again!", status="error")

    return render_template('login.html', message=None, status=None)

@routes.route('/principal_dashboard')
def principal_dashboard():
    if 'loggedin' in session and session['role'] == 'Principal':
        return render_template('principal_dashboard.html', name=session['name'])
    return redirect('/login')

@routes.route('/hod_dashboard')
def hod_dashboard():
    if 'loggedin' in session and session['role'] == 'HOD':
        return render_template('hod_dashboard.html', name=session['name'])
    return redirect('/login')


@routes.route('/teaching_staff_dashboard')
def teaching_staff_dashboard():
    if 'loggedin' in session and session['role'] == 'Teaching Staff':
        return render_template('teacher_dashboard.html', name=session['name'])
    return redirect('/login')

@routes.route('/non_teaching_dashboard')
def non_teaching_dashboard():
    if 'loggedin' in session and session['role'] == 'Non-Teaching Staff':
        return render_template('non_teaching_dashboard.html', name=session['name'])
    return redirect('/login')

@routes.route('/student_dashboard')
def student_dashboard():
    if 'loggedin' in session and session['role'] == 'Student':
        return render_template('student_dashboard.html', name=session['name'])
    return redirect('/login')


@routes.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('routes.login'))  


# hod reg manual 
def send_registration_email(to_email, full_name, username, password, role):
    from_email = "cpcs.system@gmail.com"
    from_password = "sblgtbuzrtaxppzg"
    subject = f"Welcome to CPCS - {role} Registration Successful"

    message = f"""
    Dear {full_name},

    Congratulations! You have been successfully registered as a {role} in our College Proper Communication System (CPCS).

    Your login credentials are as follows:
    -------------------------------
    Username: {username}
    Password: {password}
    -------------------------------

    Please keep this information secure.

    Regards,  
    Principal  
    CPCS System
    """

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(from_email, from_password)
            server.send_message(msg)
        print(f"Email sent to {to_email} successfully!")
    except Exception as e:
        print("Failed to send email:", e)

@routes.route('/register_hod', methods=['POST'])
def register_hod():
    data = request.form
    random_password = generate_random_password()
    password_hash = generate_password_hash(random_password)

    try:
        cur = mysql.connection.cursor()

        cur.execute("SELECT * FROM hod WHERE department = %s", (data['department'],))
        existing_hod = cur.fetchone()

        if existing_hod:
            return jsonify({
                'status': 'error',
                'message': f"HOD for the {data['department']} department already exists."
            })
        cur.execute("""
            INSERT INTO hod (full_name, email, phone, gender, department, subject_specialization,
                             highest_qualification, years_experience, password_hash)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            data['full_name'], data['email'], data['phone'], data['gender'], data['department'],
            data['subject_specialization'], data['highest_qualification'].lower(),
            data['years_experience'], password_hash
        ))
        mysql.connection.commit()
        cur.close()

        send_registration_email(data['email'], data['full_name'], data['email'], random_password, "HOD")

        return jsonify({'status': 'success', 'message': 'HOD registered successfully and email sent!'})
    except Exception as e:
        print(e)
        return jsonify({'status': 'error', 'message': 'Registration failed. Email may already exist or database error occurred.'})

@routes.route('/register_non_teaching', methods=['POST'])
def register_non_teaching():
    data = request.form
    random_password = generate_random_password()
    password_hash = generate_password_hash(random_password)

    try:
        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO non_teachingstaff (full_name, email, phone, gender, highest_qualification, department, password_hash)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            data['name'], data['email'], data['phone'], data['gender'], data['qualification'].lower(),
            data['department'], password_hash
        ))
        mysql.connection.commit()
        cur.close()

        # Send email
        send_registration_email(data['email'], data['name'], data['email'], random_password, "Non-Teaching Staff")

        return jsonify({'status': 'success', 'message': 'Non-teaching staff registered and email sent!'})
    except Exception as e:
        print(e)
        return jsonify({'status': 'error', 'message': 'Registration failed. Email or phone may already exist.'})

@routes.route('/register_student', methods=['POST'])
def register_student():
    data = request.form
    random_password = generate_random_password()
    password_hash = generate_password_hash(random_password)

    try:
        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO student (full_name, email, phone, roll_number, gender, department, year, password_hash)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            data['full_name'], data['email'], data['phone'], data['roll_number'], data['gender'],
            data['department'], data['year'], password_hash
        ))
        mysql.connection.commit()
        cur.close()

        # Send email with roll number as username
        send_registration_email(data['email'], data['full_name'], data['roll_number'], random_password, "Student")

        return jsonify({'status': 'success', 'message': 'Student registered and email sent!', 'username': data['roll_number'], 'password': random_password})
    except Exception as e:
        print(e)
        return jsonify({'status': 'error', 'message': 'Registration failed. Email or Roll Number may already exist.'})

@routes.route('/upload_student_excel', methods=['POST'])
def upload_student_excel():
    file = request.files.get('file')
    if not file or not file.filename.endswith('.xlsx'):
        return "Invalid file format. Please upload an Excel (.xlsx) file."

    filepath = os.path.join(UPLOAD_FOLDER, secure_filename(file.filename))
    file.save(filepath)

    try:
        workbook = openpyxl.load_workbook(filepath)
        sheet = workbook.active

        for row in sheet.iter_rows(min_row=2, values_only=True):
            full_name, email, phone, roll_number, gender, department, year = row
            password = generate_random_password()
            password_hash = generate_password_hash(password)

            cur = mysql.connection.cursor()
            cur.execute("""
                INSERT INTO student (full_name, email, phone, roll_number, gender, department, year, password_hash)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (full_name, email, phone, roll_number, gender, department, str(year), password_hash))
            mysql.connection.commit()
            cur.close()

            send_registration_email(email, full_name, roll_number, password, "Student")

        return "Students uploaded and registered successfully!"
    except Exception as e:
        return f"Error uploading students: {e}"
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)

# @routes.route('/upload_hod_excel', methods=['POST'])
# def upload_hod_excel():
#     file = request.files.get('file')
#     if not file or not file.filename.endswith('.xlsx'):
#         return "Invalid file format. Please upload an Excel (.xlsx) file."

#     filepath = os.path.join(UPLOAD_FOLDER, secure_filename(file.filename))
#     file.save(filepath)

#     try:
#         workbook = openpyxl.load_workbook(filepath)
#         sheet = workbook.active

#         for row in sheet.iter_rows(min_row=2, values_only=True):
#             full_name, email, phone, gender, department, subject_specialization, highest_qualification, years_experience = row
#             password = generate_random_password()
#             password_hash = generate_password_hash(password)

#             cur = mysql.connection.cursor()
#             cur.execute("""
#                 INSERT INTO hod (full_name, email, phone, gender, department, subject_specialization, highest_qualification, years_experience, password_hash)
#                 VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
#             """, (full_name, email, phone, gender, department, subject_specialization, highest_qualification.lower(), int(years_experience), password_hash))
#             mysql.connection.commit()
#             cur.close()

#             send_registration_email(email, full_name, email, password, "HOD")

#         return "HODs uploaded and registered successfully!"
#     except Exception as e:
#         return f"Error uploading HODs: {e}"
#     finally:
#         if os.path.exists(filepath):
#             os.remove(filepath)

@routes.route('/upload_teaching_excel', methods=['POST'])
def upload_teaching_excel():
    file = request.files.get('file')
    if not file or not file.filename.endswith('.xlsx'):
        return "Invalid file format. Please upload an Excel (.xlsx) file."

    filepath = os.path.join(UPLOAD_FOLDER, secure_filename(file.filename))
    file.save(filepath)

    try:
        workbook = openpyxl.load_workbook(filepath)
        sheet = workbook.active

        for row in sheet.iter_rows(min_row=2, values_only=True):
            full_name, email, phone, gender, department, subject_specialization, highest_qualification, years_experience = row
            password = generate_random_password()
            password_hash = generate_password_hash(password)

            cur = mysql.connection.cursor()
            cur.execute("""
                INSERT INTO teaching_staff (full_name, email, phone, gender, department, subject_specialization, highest_qualification, years_experience, password_hash)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (full_name, email, phone, gender, department, subject_specialization, highest_qualification.lower(), int(years_experience), password_hash))
            mysql.connection.commit()
            cur.close()

            send_registration_email(email, full_name, email, password, "Teaching Staff")

        return "Teaching staff uploaded and registered successfully!"
    except Exception as e:
        return f"Error uploading teaching staff: {e}"
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)

@routes.route('/upload_non_teaching_excel', methods=['POST'])
def upload_non_teaching_excel():
    file = request.files.get('file')
    if not file or not file.filename.endswith('.xlsx'):
        return "Invalid file format. Please upload an Excel (.xlsx) file."

    filepath = os.path.join(UPLOAD_FOLDER, secure_filename(file.filename))
    file.save(filepath)

    try:
        workbook = openpyxl.load_workbook(filepath)
        sheet = workbook.active

        for row in sheet.iter_rows(min_row=2, values_only=True):
            full_name, email, phone, gender, highest_qualification, department = row
            password = generate_random_password()
            password_hash = generate_password_hash(password)

            cur = mysql.connection.cursor()
            cur.execute("""
                INSERT INTO non_teachingstaff (full_name, email, phone, gender, highest_qualification, department, password_hash)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (full_name, email, phone, gender, highest_qualification.lower(), department, password_hash))
            mysql.connection.commit()
            cur.close()

            send_registration_email(email, full_name, email, password, "Non-Teaching Staff")

        return "Non-teaching staff uploaded and registered successfully!"
    except Exception as e:
        return f"Error uploading non-teaching staff: {e}"
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)



# announcements
@announcement_bp.route("/send_announcement", methods=["POST"])
def send_announcement():
    sender_name = session.get("name", "Unknown")  
    file = request.files.get("pdf")
    filename = None

    if file and file.filename.endswith(".pdf"):
        filename = secure_filename(file.filename)
        upload_path = os.path.join(current_app.root_path, "static", "uploads")
        os.makedirs(upload_path, exist_ok=True)
        file.save(os.path.join(upload_path, filename))

    announcement = Announcement(
        title=request.form["title"],
        message=request.form["message"],
        sender_name=sender_name,
        pdf_filename=filename
    )
    db.session.add(announcement)
    db.session.commit()

    return jsonify({"status": "success", "message": "Announcement sent successfully!"})

@announcement_bp.route("/get_announcements", methods=["GET"])
def get_announcements():
    receiver_name = session.get("name", "User") 

    announcements = Announcement.query.order_by(Announcement.timestamp.desc()).all()
    base_url = url_for('static', filename='uploads/', _external=True)

    data = [
        {
            "title": a.title,
            "message": a.message,
            "pdf_url": f"{base_url}{a.pdf_filename}" if a.pdf_filename else None,
            "timestamp": a.timestamp.strftime("%Y-%m-%d %H:%M"),
            "sender_name": a.sender_name,
            "receiver_name": receiver_name
        }
        for a in announcements
    ]
    return jsonify({"announcements": data})

# setings

def get_table_name(role):
    role_table_map = {
        'Principal': 'principal',
        'HOD': 'hod',
        'Teaching Staff': 'teaching_staff',
        'Non-Teaching Staff': 'non_teachingstaff',
        'Student': 'student'
    }
    return role_table_map.get(role)

@settings_bp.route('/update_details', methods=['POST'])
def update_details():
    user_id = session.get('user_id')  # roll_number for students
    role = session.get('role')
    name = request.json.get('name')
    email = request.json.get('email')

    if not user_id or not role:
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401

    table = get_table_name(role)
    if not table:
        return jsonify({'status': 'error', 'message': 'Invalid user role'}), 400

    cur = mysql.connection.cursor()
    try:
        if role.lower() == 'student':
            cur.execute(f"UPDATE {table} SET full_name=%s, email=%s WHERE roll_number=%s", (name, email, user_id))
        else:
            cur.execute(f"UPDATE {table} SET full_name=%s, email=%s WHERE email=%s", (name, email, user_id))
        mysql.connection.commit()

        # For student, session user_id remains roll_number
        if role.lower() != 'student':
            session['user_id'] = email

        return jsonify({'status': 'success', 'message': 'Details updated successfully'})
    except Exception as e:
        print(f"Error while updating: {e}")
        return jsonify({'status': 'error', 'message': 'Database error occurred.'}), 500
    finally:
        cur.close()

@settings_bp.route('/change_password', methods=['POST'])
def change_password():
    user_id = session.get('user_id')  # roll_number for student
    role = session.get('role')

    if not user_id or not role:
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401

    table = get_table_name(role)
    if not table:
        return jsonify({'status': 'error', 'message': 'Invalid user role'}), 400

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    if role.lower() == 'student':
        cur.execute(f"SELECT password_hash FROM {table} WHERE roll_number=%s", (user_id,))
    else:
        cur.execute(f"SELECT password_hash FROM {table} WHERE email=%s", (user_id,))
    user = cur.fetchone()

    if not user:
        cur.close()
        return jsonify({'status': 'error', 'message': 'User not found'}), 404

    current_password = request.json.get('current_password')
    new_password = request.json.get('new_password')

    if not check_password_hash(user['password_hash'], current_password):
        cur.close()
        return jsonify({'status': 'error', 'message': 'Current password is incorrect'}), 403

    new_password_hash = generate_password_hash(new_password)
    if role.lower() == 'student':
        cur.execute(f"UPDATE {table} SET password_hash=%s WHERE roll_number=%s", (new_password_hash, user_id))
    else:
        cur.execute(f"UPDATE {table} SET password_hash=%s WHERE email=%s", (new_password_hash, user_id))

    mysql.connection.commit()
    cur.close()

    return jsonify({'status': 'success', 'message': 'Password changed successfully'})

# notification

@routes.route('/get-users/<module>', methods=['GET'])
def get_users(module):
    table_map = {
        "hod": "hod",
        "teaching_staff": "teaching_staff",
        "non_teaching_staff": "non_teachingstaff",
        "student": "student"
    }

    if module not in table_map:
        return jsonify([])

    cur = mysql.connection.cursor()
    cur.execute(f"SELECT id, full_name, email FROM {table_map[module]}")
    users = cur.fetchall()
    cur.close()

    return jsonify([{'id': row[0], 'name': row[1], 'email': row[2]} for row in users])

@routes.route('/send-notification', methods=['POST'])
def send_notification():
    data = request.get_json()
    module = data['module']
    user_ids = data['userIds']
    message_content = data['message']
    
    sender_name = session.get('name', 'Someone')  # FIXED: correct session key

    table_map = {
        "hod": "hod",
        "teaching_staff": "teaching_staff",
        "non_teaching_staff": "non_teachingstaff",
        "student": "student"
    }

    if module not in table_map:
        return jsonify({"message": "Invalid module"}), 400

    cur = mysql.connection.cursor()
    for uid in user_ids:
        cur.execute(f"SELECT full_name FROM {table_map[module]} WHERE id = %s", (uid,))
        receiver = cur.fetchone()
        receiver_name = receiver[0] if receiver else "User"

        personalized_message = (
            f"Hi {receiver_name}, you have received a notification from {sender_name}.\n"
            f"{message_content}"
        )

        cur.execute("""
            INSERT INTO notifications (module, user_id, sender_name, receiver_name, message)
            VALUES (%s, %s, %s, %s, %s)
        """, (module, uid, sender_name, receiver_name, personalized_message))

    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Notification sent successfully!"})


@routes.route('/view_notifications', methods=['GET'])
def view_notifications():
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT sender_name, receiver_name, message, timestamp
        FROM notifications
        ORDER BY timestamp DESC
    """)
    notifications = cur.fetchall()
    cur.close()

    result = []
    for row in notifications:
        result.append({
            'sender': row[0],
            'receiver': row[1],
            'message': row[2],
            'timestamp': row[3].strftime('%a, %d %b %Y %H:%M:%S GMT')
        })

    return jsonify(result)


# dashboard
@routes.route('/view/hods')
def view_hods():
    hods = HOD.query.all()
    return jsonify([
        {
            'name': h.full_name,
            'department': h.department,
            'subject': h.subject_specialization
        } for h in hods
    ])

@routes.route('/view/teachers')
def view_teachers():
    teachers = TeachingStaff.query.all()
    return jsonify([
        {
            'name': t.full_name,
            'department': t.department,
            'subject': t.subject_specialization
        } for t in teachers
    ])

@routes.route('/view/non_teaching')
def view_non_teaching():
    staff = NonTeachingStaff.query.all()
    return jsonify([
        {
            'name': s.full_name,
            'department': s.department
        } for s in staff
    ])

@routes.route('/view/students')
def view_students():
    students = Student.query.all()
    return jsonify([
        {
            'name': s.full_name,
            'department': s.department,
            'year': s.year
        } for s in students
    ])


# meetings
# meetings
@meeting_bp.route("/schedule_meeting", methods=["POST"])
def schedule_meeting():
    try:
        data = request.get_json()

        topic = data.get("topic")
        date = data.get("date")
        time = data.get("time")
        message = data.get("message")
        departments = data.get("departments", [])

        sender_name = session.get("name", "Principal")

        if not (topic and date and time and message and departments):
            return jsonify({"status": "error", "message": "All fields are required."}), 400

        print(f"Scheduling meeting: {topic} on {date} at {time} for depts: {departments}")

        # Avoid duplicates by not using accidental refresh logic or retries here
        for dept in departments:
            meeting = Meeting(
                topic=topic,
                date=date,
                time=time,
                message=message,
                sender_name=sender_name,
                receiver_department=dept.upper()  # store as uppercase for consistency
            )
            db.session.add(meeting)

        db.session.commit()
        return jsonify({"status": "success", "message": "Meeting scheduled successfully!"})

    except Exception as e:
        print("Error scheduling meeting:", e)
        return jsonify({"status": "error", "message": "Something went wrong!"}), 500

@meeting_bp.route("/get_meetings", methods=["GET"])
def get_meetings():
    try:
        receiver_name = session.get("name", "User")
        department = session.get("department", "General").upper()

        # Initialize meetings as an empty list in case no records are found
        meetings = []

        # Query for meetings
        meetings = Meeting.query.filter(
            (Meeting.receiver_department == department) | 
            (Meeting.receiver_department == 'ALL')
        ).order_by(Meeting.timestamp.desc()).all()

        # Prepare personalized meetings list
        personalized_meetings = []
        for m in meetings:
            personalized_meetings.append({
                "topic": m.topic,
                "date": m.date,
                "time": m.time,
                "message": m.message,
                "sender_name": m.sender_name,
                "receiver_name": receiver_name,
                "timestamp": m.timestamp.strftime("%Y-%m-%d %H:%M")
            })

        return jsonify({"meetings": personalized_meetings})

    except Exception as e:
        print("Error fetching meetings:", e)
        return jsonify({"status": "error", "message": "Something went wrong!"}), 500

# Grievance
@grievance_bp.route("/get_recipients/<recipient_type>")
def get_recipients(recipient_type):
    if recipient_type == "hod":
        result = HOD.query.with_entities(HOD.full_name, HOD.email).all()
    elif recipient_type == "teacher":
        result = TeachingStaff.query.with_entities(TeachingStaff.full_name, TeachingStaff.email).all()
    elif recipient_type == "non_teaching":
        result = NonTeachingStaff.query.with_entities(NonTeachingStaff.full_name, NonTeachingStaff.email).all()
    else:
        result = []

    recipients = [{"full_name": r[0], "email": r[1]} for r in result]
    return jsonify({"recipients": recipients})


@grievance_bp.route("/submit_grievance", methods=["POST"])
def submit_grievance():
    data = request.get_json()

    student_name = session.get("full_name")
    roll_number = session.get("roll_number")
    recipient_type = data.get("recipient_type")
    recipient_email = data.get("recipient_email")
    query = data.get("query")

    print("Received data:", data)
    print("Session full_name:", student_name)
    print("Session roll_number:", roll_number)

    if not (student_name and roll_number and recipient_type and recipient_email and query):
        print("Missing one or more fields!")
        return jsonify({"status": "error", "message": "Missing data!"}), 400

    grievance = Grievance(
        student_name=student_name,
        roll_number=roll_number,
        recipient_type=recipient_type,
        recipient_email=recipient_email,
        query=query
    )
    db.session.add(grievance)
    db.session.commit()
    print(f"Grievance submitted: {grievance}")

    return jsonify({"status": "success", "message": "Grievance submitted successfully!"})

@grievance_bp.route("/view_grievances")
def view_grievances():
    current_user_email = session.get("email")
    print(f"Current user email from session: {current_user_email}")

    
    # Using filter() with correct syntax for SQLAlchemy query
    grievances = db.session.query(Grievance).filter(Grievance.recipient_email == current_user_email).order_by(Grievance.timestamp.desc()).all()

    grievance_data = [{
        "student_name": g.student_name,
        "roll_number": g.roll_number,
        "query": g.query,
        "timestamp": g.timestamp.strftime("%d %b %Y, %I:%M %p")


    } for g in grievances]

    return jsonify({"grievances": grievance_data})

@grievance_bp.route("/reply_grievance", methods=["POST"])
def reply_grievance():
    data = request.get_json()
    roll_number = data.get("roll_number")
    timestamp_str = data.get("timestamp")
    reply_text = data.get("reply")

    if not (roll_number and timestamp_str and reply_text):
        return jsonify({"status": "error", "message": "Incomplete data"}), 400

    from datetime import datetime
    try:
        timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        try:
            timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M")
        except ValueError:
            return jsonify({"status": "error", "message": "Invalid timestamp format"}), 400

    current_user_email = session.get("email")

    grievance = db.session.query(Grievance).filter(
        Grievance.roll_number == roll_number,
        Grievance.timestamp == timestamp,
        Grievance.recipient_email == current_user_email
    ).first()

    if grievance:
        grievance.reply = reply_text
        db.session.commit()
        return jsonify({"status": "success", "message": "Reply sent successfully!"})
    else:
        return jsonify({"status": "error", "message": "Grievance not found!"}), 404

@grievance_bp.route("/view_submitted_grievances")
def view_submitted_grievances():
    student_roll = session.get("roll_number")
    if not student_roll:
        return jsonify({"status": "error", "message": "Not logged in"}), 401

    grievances = db.session.query(Grievance).filter(
        Grievance.roll_number == student_roll
    ).order_by(Grievance.timestamp.desc()).all()

    grievance_data = [{
        "recipient_email": g.recipient_email,
        "query": g.query,
        "timestamp": g.timestamp.strftime("%d %b %Y, %I:%M %p"),
        "reply": g.reply
    } for g in grievances]

    return jsonify({"status": "success", "grievances": grievance_data})


# manage hod
@admin_bp.route('/get_hods', methods=['GET'])
def get_hods():
    hods = HOD.query.all()
    hod_list = [{
        'id': hod.id,
        'full_name': hod.full_name,
        'email': hod.email,
        'phone': hod.phone,
        'department': hod.department
    } for hod in hods]
    return jsonify(hod_list)

@admin_bp.route('/delete_hod/<int:hod_id>', methods=['DELETE'])
def delete_hod(hod_id):
    hod = HOD.query.get(hod_id)
    if hod:
        db.session.delete(hod)
        db.session.commit()
        return '', 204 
    else:
        return jsonify({"error": "HOD not found"}), 404

# manage teaching
@admin_bp.route('/get_teaching_staff', methods=['GET'])
def get_teaching_staff():
    staff = TeachingStaff.query.all()
    return jsonify([{
        'id': s.id,
        'full_name': s.full_name,
        'email': s.email,
        'phone': s.phone,
        'department': s.department,
        'subject_specialization': s.subject_specialization
    } for s in staff])

# Delete
@admin_bp.route('/delete_teaching/<int:id>', methods=['DELETE'])
def delete_teaching(id):
    staff = TeachingStaff.query.get(id)
    if staff:
        db.session.delete(staff)
        db.session.commit()
        return '', 204
    return jsonify({'error': 'Not found'}), 404

@admin_bp.route('/get_non_teaching_staff', methods=['GET'])
def get_non_teaching_staff():
    staff = NonTeachingStaff.query.all()
    return jsonify([{
        'id': s.id,
        'full_name': s.full_name,
        'email': s.email,
        'phone': s.phone,
        'department': s.department
    } for s in staff])

@admin_bp.route('/get_students', methods=['GET'])
def get_students():
    students = Student.query.all()
    return jsonify([{
        'id': s.id,
        'full_name': s.full_name,
        'email': s.email,
        'phone': s.phone,
        'roll_number': s.roll_number,
        'department': s.department,
        'year': s.year
    } for s in students])

@admin_bp.route('/delete_non_teaching/<int:id>', methods=['DELETE'])
def delete_non_teaching(id):
    staff = NonTeachingStaff.query.get(id)
    if staff:
        db.session.delete(staff)
        db.session.commit()
        return '', 204
    return jsonify({'error': 'Not found'}), 404

@admin_bp.route('/delete_student/<int:id>', methods=['DELETE'])
def delete_student(id):
    student = Student.query.get(id)
    if student:
        db.session.delete(student)
        db.session.commit()
        return '', 204
    return jsonify({'error': 'Not found'}), 404


UPLOAD_FOLDER = 'static/profile_photos'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Helper function
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@routes.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'loggedin' not in session:
        return redirect('/login')

    role = session['role']
    email_or_roll = session['user_id']

    role_model_map = {
        'Principal': Principal,
        'HOD': HOD,
        'Teaching Staff': TeachingStaff,
        'Non-Teaching Staff': NonTeachingStaff,
        'Student': Student
    }

    dashboard_map = {
        'Principal': 'principal_dashboard',
        'HOD': 'hod_dashboard',
        'Teaching Staff': 'teaching_staff_dashboard',
        'Non-Teaching Staff': 'non_teaching_dashboard',
        'Student': 'student_dashboard'
    }

    model = role_model_map.get(role)
    if not model:
        return "Invalid role", 400

    lookup_field = 'email' if role != 'Student' else 'roll_number'
    user = model.query.filter(getattr(model, lookup_field) == email_or_roll).first()

    if request.method == 'POST' and 'profile_photo' in request.files:
        file = request.files['profile_photo']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            user.profile_photo = filename
            db.session.commit()
            session['profile_photo'] = filename

            return redirect(url_for('routes.profile', uploaded='true'))

    dashboard_url = dashboard_map.get(role, 'login')

    return render_template('profile.html', user=user, role=role, dashboard_url=dashboard_url)

UPLOAD_FOLDER = 'static/profile_photos'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@routes.route('/upload_profile_photo', methods=['POST'])
def upload_profile_photo():
    if 'user_id' not in session or 'role' not in session:
        return redirect(url_for('routes.login'))

    role = session['role']
    email_or_roll = session['user_id']

    role_model_map = {
        'Principal': Principal,
        'HOD': HOD,
        'Teaching Staff': TeachingStaff,
        'Non-Teaching Staff': NonTeachingStaff,
        'Student': Student
    }

    model = role_model_map.get(role)
    if not model:
        return "Invalid role", 400

    lookup_field = 'email' if role != 'Student' else 'roll_number'
    user = model.query.filter(getattr(model, lookup_field) == email_or_roll).first()

    if not user:
        return "User not found", 404

    file = request.files.get('profile_photo')
    if file and allowed_file(file.filename):
        # File size check (2MB)
        file.seek(0, os.SEEK_END)
        file_length = file.tell()
        file.seek(0)  # Reset file pointer

        if file_length > 2 * 1024 * 1024:  # 2MB
            return redirect(url_for('routes.profile', uploaded='size_error'))

        filename = secure_filename(file.filename)
        filepath = os.path.join('static/profile_photos', filename)
        file.save(filepath)

        user.profile_photo = filename
        db.session.commit()
        session['profile_photo'] = filename

        return redirect(url_for('routes.profile', uploaded='true'))

    return redirect(url_for('routes.profile', uploaded='false'))
