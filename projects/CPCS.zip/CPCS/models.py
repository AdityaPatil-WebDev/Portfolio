from extensions import db
from datetime import datetime


class Meeting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String(255), nullable=False)
    date = db.Column(db.String(20), nullable=False)
    time = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=False)
    sender_name = db.Column(db.String(100), nullable=False)
    receiver_department = db.Column(db.String(100), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)



class Announcement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    pdf_filename = db.Column(db.String(200), nullable=True)
    sender_name = db.Column(db.String(100), nullable=False) 
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)



class HOD(db.Model):
    __tablename__ = 'hod'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(10), nullable=False)
    gender = db.Column(db.Enum('male', 'female'), nullable=False)
    department = db.Column(db.String(50), nullable=False)
    subject_specialization = db.Column(db.String(100), nullable=False)
    highest_qualification = db.Column(db.Enum('mca', 'mtech', 'btech', 'ma', 'bed', 'msc', 'phd'), nullable=False)
    years_experience = db.Column(db.Integer, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    profile_photo = db.Column(db.String(100), default=None)  # Stores the filename


class TeachingStaff(db.Model):
    __tablename__ = 'teaching_staff'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    phone = db.Column(db.String(10), unique=True)
    gender = db.Column(db.String(10))
    department = db.Column(db.String(50))
    subject_specialization = db.Column(db.String(100))
    highest_qualification = db.Column(db.String(50))
    years_experience = db.Column(db.Integer)
    password_hash = db.Column(db.Text)
    profile_photo = db.Column(db.String(100), default=None)  # Stores the filename


class NonTeachingStaff(db.Model):
    __tablename__ = 'non_teachingstaff'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    phone = db.Column(db.String(10), nullable=False, unique=True)
    gender = db.Column(db.String(10), nullable=False)
    highest_qualification = db.Column(db.String(50), nullable=False)
    department = db.Column(db.String(50), nullable=False)
    password_hash = db.Column(db.Text, nullable=False)
    profile_photo = db.Column(db.String(100), default=None)  # Stores the filename


class Student(db.Model):
    __tablename__ = 'student'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    phone = db.Column(db.String(15))
    roll_number = db.Column(db.String(50))
    gender = db.Column(db.String(10))
    department = db.Column(db.String(50))
    year = db.Column(db.String(20))
    password_hash = db.Column(db.Text)
    profile_photo = db.Column(db.String(100), default=None)  # Stores the filename



class Grievance(db.Model):
    __tablename__ = 'grievances'

    id = db.Column(db.Integer, primary_key=True)
    student_name = db.Column(db.String(100), nullable=False)
    roll_number = db.Column(db.String(20), nullable=False)
    recipient_type = db.Column(db.String(50), nullable=False)  # e.g., "hod", "teacher", etc.
    recipient_email = db.Column(db.String(100), nullable=False)
    query = db.Column(db.Text, nullable=False)
    reply = db.Column(db.Text)  # optional, null until replied
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Grievance {self.id} - {self.roll_number}>"

class Principal(db.Model):
    __tablename__ = 'principal'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    profile_photo = db.Column(db.String(100), default=None)  # Stores filename like 'principal1.jpg'

    def __repr__(self):
        return f"<Principal {self.name}>"