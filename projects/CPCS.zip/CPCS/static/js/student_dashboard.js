const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');
allSideMenu.forEach(item => {
	const li = item.parentElement;
	item.addEventListener('click', function () {
		allSideMenu.forEach(i => i.parentElement.classList.remove('active'));
		li.classList.add('active');
	});
});

// Sidebar Toggle
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');
menuBar.addEventListener('click', () => sidebar.classList.toggle('hide'));

// Responsive Search
const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = searchButton.querySelector('i');
const searchForm = document.querySelector('#content nav form');
searchButton.addEventListener('click', function (e) {
	if (window.innerWidth < 576) {
		e.preventDefault();
		searchForm.classList.toggle('show');
		searchButtonIcon.classList.toggle('bx-search');
		searchButtonIcon.classList.toggle('bx-x');
	}
});

window.addEventListener('resize', () => {
	if (window.innerWidth > 576) {
		searchForm.classList.remove('show');
		searchButtonIcon.classList.remove('bx-x');
		searchButtonIcon.classList.add('bx-search');
	}
});

// Dark Mode
const switchMode = document.getElementById('switch-mode');
switchMode.addEventListener('change', function () {
	document.body.classList.toggle('dark', this.checked);
});

// Dropdowns
const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
dropdownToggles.forEach(toggle => {
	toggle.addEventListener('click', e => {
		e.preventDefault();
		toggle.nextElementSibling.classList.toggle('show');
	});
});

// Section Display Functions
function showOnly(sectionId) {
	const sections = [
		"dashboardSection",
		"grievanceSection",
		"announcementsSection",
		"notificationsSection",
		"settingsSection"
	];
	sections.forEach(id => {
		document.getElementById(id).style.display = (id === sectionId) ? "block" : "none";
	});
}

document.addEventListener("DOMContentLoaded", function () {
	showOnly("dashboardSection");

	document.getElementById("dashboardBtn").addEventListener("click", e => {
		e.preventDefault();
		showOnly("dashboardSection");
	});

	document.getElementById("graviencesBtn").addEventListener("click", e => {
		e.preventDefault();
		showOnly("grievanceSection");
	});

	document.getElementById("announcementsBtn").addEventListener("click", e => {
		e.preventDefault();
		showOnly("announcementsSection");
	});

	document.getElementById("notificationsBtn").addEventListener("click", e => {
		e.preventDefault();
		showOnly("notificationsSection");
	});

	document.getElementById("settingsBtn").addEventListener("click", e => {
		e.preventDefault();
		showOnly("settingsSection");
	});
});

// notify
document.getElementById("viewNotificationBtn").addEventListener("click", function () {
    fetch('/view_notifications')
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length === 0) {
                html = "<p>No notifications found.</p>";
            } else {
                data.forEach(n => {
					html += `<div class="notification-card">
								<strong>To:</strong> ${n.receiver} <br>
								<strong>From:</strong> ${n.sender} <br>
								<strong>Message:</strong> ${n.message} <br>
								<strong>Time:</strong> ${n.timestamp}
							 </div><hr>`;
				});
				
            }
            document.getElementById("notificationList").innerHTML = html;
        })
        .catch(error => {
            document.getElementById("notificationList").innerHTML = "<p>Error loading notifications.</p>";
            console.error("Error:", error);
        });
});

// dashboard

function fetchAndDisplay(category) {
    const urlMap = {
        'hods': '/view/hods',
        'teachers': '/view/teachers',
        'non_teaching': '/view/non_teaching',
        'students': '/view/students'
    };

    fetch(urlMap[category])
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('details-container');
            container.innerHTML = `<h3>${category.replace('_', ' ').toUpperCase()}</h3><ul></ul>`;
            const list = container.querySelector('ul');

            data.forEach(item => {
                let li = document.createElement('li');
                if (category === 'teachers' || category === 'hods') {
                    li.textContent = `${item.name} | ${item.department} | ${item.subject}`;
                } else if (category === 'students') {
                    li.textContent = `${item.name} | ${item.department} | Year: ${item.year}`;
                } else {
                    li.textContent = `${item.name} | ${item.department}`;
                }
                list.appendChild(li);
            });
        })
        .catch(err => console.error('Error fetching data:', err));
}
    // settings
    
    document.getElementById("updateDetailsForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("updateName").value;
        const email = document.getElementById("updateEmail").value;
    
        fetch("/update_details", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include", 
            body: JSON.stringify({ name: name, email: email })
        })
        
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while updating details.");
        });
    });
    
    document.getElementById("changePasswordForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const currentPassword = document.getElementById("currentPassword").value;
        const newPassword = document.getElementById("newPassword").value;
        const confirmPassword = document.getElementById("confirmPassword").value;
    
        if (newPassword !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }
    
        fetch("/change_password", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",  
            body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })

        })
        
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while changing password.");
        });
    });