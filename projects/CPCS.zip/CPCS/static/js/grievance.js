document.addEventListener("DOMContentLoaded", () => {
    // Handle dynamic recipient loading
    const recipientTypeSelect = document.getElementById("recipientType");
    const recipientEmailSelect = document.getElementById("recipientEmail");
    const grievanceForm = document.getElementById("grievanceForm");

    if (recipientTypeSelect && recipientEmailSelect) {
        recipientTypeSelect.addEventListener("change", () => {
            const type = recipientTypeSelect.value;

            fetch(`/get_recipients/${type}`)
                .then(res => res.json())
                .then(data => {
                    recipientEmailSelect.innerHTML = '<option value="" disabled selected>Select Recipient</option>';
                    data.recipients.forEach(r => {
                        const option = document.createElement("option");
                        option.value = r.email;
                        option.textContent = `${r.full_name} (${r.email})`; // fixed
                        recipientEmailSelect.appendChild(option);
                    });
                });
        });
    }

    // Handle grievance submission
    if (grievanceForm) {
        grievanceForm.addEventListener("submit", e => {
            e.preventDefault();
            const recipientType = recipientTypeSelect.value;
            const recipientEmail = recipientEmailSelect.value;
            const query = document.getElementById("query").value;

            if (!recipientType || !recipientEmail || !query) {
                alert("All fields are required!");
                return;
            }

            fetch("/submit_grievance", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    recipient_type: recipientType,
                    recipient_email: recipientEmail,
                    query: query
                })
            })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                grievanceForm.reset();
            });
        });
    }

    // Load grievances in view page (if grievanceList div is present)
    const list = document.getElementById("grievanceList");
    if (list) {
        fetch("/view_grievances")
            .then(res => {
                if (!res.ok) throw new Error("Failed to load grievances");
                return res.json();
            })
            .then(data => {
                if (data.grievances && data.grievances.length > 0) {
                    data.grievances.forEach(g => {
    const div = document.createElement("div");
    div.classList.add("grievance-item");

    // Main grievance content
    let content = `
        <strong>From:</strong> ${g.student_name} (${g.roll_number})<br>
        <strong>Query:</strong> ${g.query}<br>
        <small><i>${g.timestamp}</i></small><br>
    `;

    // Add reply section
    content += `
        <textarea placeholder="Write a reply..." rows="2" cols="50" class="reply-text"></textarea><br>
        <button class="reply-btn">Reply</button>
        <div class="reply-status"></div>
    `;

    div.innerHTML = content;

    // Add event listener for reply button
    const button = div.querySelector(".reply-btn");
    button.addEventListener("click", () => {
        const replyText = div.querySelector(".reply-text").value.trim();
        if (!replyText) {
            alert("Reply cannot be empty!");
            return;
        }

        fetch("/reply_grievance", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                roll_number: g.roll_number,
                timestamp: g.timestamp,
                reply: replyText
            })
        })
        .then(res => res.json())
        .then(data => {
            div.querySelector(".reply-status").innerHTML = `<p style="color: green;">${data.message}</p>`;
        })
        .catch(err => {
            console.error(err);
            div.querySelector(".reply-status").innerHTML = `<p style="color: red;">Failed to send reply.</p>`;
        });
    });

    list.appendChild(div);
});

                } else {
                    list.innerHTML = "<p>No grievances found.</p>";
                }
            })
            .catch(err => {
                console.error(err);
                list.innerHTML = "<p><b>Error loading grievances.</b></p>";
            });
    }
});

const submittedList = document.getElementById("submittedGrievanceList");

if (submittedList) {
    fetch("/view_submitted_grievances")
        .then(res => {
            if (!res.ok) {
                throw new Error("Network response was not ok");
            }
            return res.json();
        })
        .then(data => {
            if (data.status === "success" && data.grievances.length > 0) {
                data.grievances.forEach(g => {
                    const div = document.createElement("div");
                    div.classList.add("grievance-item");
                    div.innerHTML = `
                        <strong>To:</strong> ${g.recipient_email}<br>
                        <strong>Query:</strong> ${g.query}<br>
                        <strong>Submitted:</strong> ${g.timestamp}<br>
                        <strong>Reply:</strong> ${g.reply ? g.reply : "<i>No reply yet</i>"}
                        <hr>
                    `;
                    submittedList.appendChild(div);
                });
            } else {
                submittedList.innerHTML = "<p>You haven't submitted any grievances.</p>";
            }
        })
        .catch(err => {
            console.error("Grievance fetch error:", err);
            submittedList.innerHTML = "<p><b>Error loading grievances.</b></p>";
        });
}
