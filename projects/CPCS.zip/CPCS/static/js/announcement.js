document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("announcementForm");
    const announcementsList = document.getElementById("announcementsList");
    const viewBtn = document.getElementById("viewAnnouncementBtn");
    const section = document.getElementById("announcementsSection");

    // Sending Announcement
    form?.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(form);

        fetch("/send_announcement", {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            form.reset();
            if (typeof fetchAnnouncements === "function") {
                fetchAnnouncements(); // Refresh announcements list after sending
            }
        })
        .catch(err => console.error("Error sending announcement:", err));
    });

    // Receiving/Viewing Announcements
    viewBtn?.addEventListener("click", function () {
        const list = document.getElementById("announcementsList");
        if (list) list.style.display = "block"; // Show the announcements
        fetchAnnouncements();
    });
    

    function fetchAnnouncements() {
        fetch("/get_announcements")
            .then(res => res.json())
            .then(data => {
                if (!data.announcements) {
                    console.warn("No announcements found.");
                    return;
                }

                // Clear previous announcements
                if (announcementsList) {
                    announcementsList.innerHTML = "";
                } else if (section) {
                    section.querySelectorAll(".announcement-container").forEach(c => c.remove());
                }

                data.announcements.forEach(a => {
                    const div = document.createElement("div");
                    div.classList.add("mb-4", "p-2", "border", "rounded", "announcement-container");
                    div.innerHTML = `
                        <p><strong>Hi ${a.receiver_name || "everyone"},</strong> you received an announcement from <strong>${a.sender_name}</strong></p>
                        <strong>Title:</strong> ${a.title}<br>
                        <p>${a.message}</p>
                        ${a.pdf_url ? `<a href="${a.pdf_url}" target="_blank">📎 View PDF</a><br>` : ""}
                        <small><i>${a.timestamp}</i></small>
                        <hr>
                    `;

                    if (announcementsList) {
                        announcementsList.appendChild(div);
                    }
                    
                });
            })
            .catch(err => console.error("Error fetching announcements:", err));
    }
});
