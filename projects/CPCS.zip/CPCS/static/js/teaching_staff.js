document.addEventListener("DOMContentLoaded", function () {
    // Sidebar Menu Active State
    const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');
    allSideMenu.forEach(item => {
        const li = item.parentElement;
        item.addEventListener('click', function () {
            allSideMenu.forEach(i => i.parentElement.classList.remove('active'));
            li.classList.add('active');
        });
    });

    // Toggle Sidebar
    const menuBar = document.querySelector('#content nav .bx.bx-menu');
    const sidebar = document.getElementById('sidebar');

    menuBar?.addEventListener('click', function () {
        sidebar.classList.toggle('hide');
    });

    // Dark Mode Toggle
    const switchMode = document.getElementById('switch-mode');
    switchMode?.addEventListener('change', function () {
        document.body.classList.toggle('dark', this.checked);
    });

    // Dropdown Toggle
    document.querySelectorAll(".dropdown-toggle").forEach(toggle => {
        toggle.addEventListener("click", function (e) {
            e.preventDefault();
            const dropdownMenu = this.nextElementSibling;
            dropdownMenu?.classList.toggle('show');
        });
    });

    // Function to Show Only Selected Section
    function showSection(sectionId) {
        document.querySelectorAll('main > div').forEach(section => {
            section.style.display = 'none';
        });

        const selectedSection = document.getElementById(sectionId);
        if (selectedSection) {
            selectedSection.style.display = 'block';
        }
    }

    // Ensure Dashboard is Default Visible
    showSection("dashboardSection");

    // Sidebar Navigation
    document.getElementById("dashboardBtn")?.addEventListener("click", function (event) {
        event.preventDefault();
        showSection("dashboardSection");
    });
    document.getElementById("meetingsBtn")?.addEventListener("click", function (event) {
        event.preventDefault();
        showSection("meetingsListSection");
    });
    
    document.getElementById("announcementsBtn")?.addEventListener("click", function (event) {
        event.preventDefault();
        showSection("announcementsSection");
    });
    document.getElementById("notificationsBtn")?.addEventListener("click", function (event) {
        event.preventDefault();
        showSection("notificationsSection");
    });
    document.getElementById("grievanceBtn")?.addEventListener("click", function (event) {
        event.preventDefault();
        showSection("grievanceListSection");
    });
    document.getElementById("settingsBtn")?.addEventListener("click", function (event) {
        event.preventDefault();
        showSection("settingsSection");
    });

    // Announcements - Send Functionality
    document.getElementById("sendAnnouncementBtn")?.addEventListener("click", function () {
        let announcementDiv = document.getElementById("announcementInputDiv");

        if (!announcementDiv) {
            announcementDiv = document.createElement("div");
            announcementDiv.id = "announcementInputDiv";
            announcementDiv.innerHTML = `
                <textarea id="announcementText" placeholder="Type your announcement here..." rows="4" style="width:100%; padding:8px; margin-top:10px;"></textarea>
                <button id="submitAnnouncement" style="margin-top:10px; padding:6px 12px;">Submit</button>
            `;
            document.getElementById("announcementsSection").appendChild(announcementDiv);

            document.getElementById("submitAnnouncement").addEventListener("click", function () {
                const text = document.getElementById("announcementText").value;
                if (text.trim() !== "") {
                    alert("Announcement sent: " + text);
                    document.getElementById("announcementText").value = "";
                } else {
                    alert("Please write an announcement before submitting.");
                }
            });
        }
    });

});

// dashboard

function fetchAndDisplay(category) {
    const urlMap = {
        'hods': '/view/hods',
        'teachers': '/view/teachers',
        'non_teaching': '/view/non_teaching',
        'students': '/view/students'
    };

    fetch(urlMap[category])
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('details-container');
            container.innerHTML = `<h3>${category.replace('_', ' ').toUpperCase()}</h3><ul></ul>`;
            const list = container.querySelector('ul');

            data.forEach(item => {
                let li = document.createElement('li');
                if (category === 'teachers' || category === 'hods') {
                    li.textContent = `${item.name} | ${item.department} | ${item.subject}`;
                } else if (category === 'students') {
                    li.textContent = `${item.name} | ${item.department} | Year: ${item.year}`;
                } else {
                    li.textContent = `${item.name} | ${item.department}`;
                }
                list.appendChild(li);
            });
        })
        .catch(err => console.error('Error fetching data:', err));
}
// notify
document.getElementById("viewNotificationBtn").addEventListener("click", function () {
    fetch('/view_notifications')
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length === 0) {
                html = "<p>No notifications found.</p>";
            } else {
                data.forEach(n => {
					html += `<div class="notification-card">
								<strong>To:</strong> ${n.receiver} <br>
								<strong>From:</strong> ${n.sender} <br>
								<strong>Message:</strong> ${n.message} <br>
								<strong>Time:</strong> ${n.timestamp}
							 </div><hr>`;
				});
				
            }
            document.getElementById("notificationList").innerHTML = html;
        })
        .catch(error => {
            document.getElementById("notificationList").innerHTML = "<p>Error loading notifications.</p>";
            console.error("Error:", error);
        });
});

    // settings
    
    document.getElementById("updateDetailsForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("updateName").value;
        const email = document.getElementById("updateEmail").value;
    
        fetch("/update_details", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include", 
            body: JSON.stringify({ name: name, email: email })
        })
        
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while updating details.");
        });
    });
    
    document.getElementById("changePasswordForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const currentPassword = document.getElementById("currentPassword").value;
        const newPassword = document.getElementById("newPassword").value;
        const confirmPassword = document.getElementById("confirmPassword").value;
    
        if (newPassword !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }
    
        fetch("/change_password", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",  
            body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })

        })
        
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while changing password.");
        });
    });

 const sendBtn = document.getElementById('sendNotificationBtn');
    const viewBtn = document.getElementById('viewNotificationBtn');
    const sendForm = document.getElementById('sendNotificationForm');
    const notificationList = document.getElementById('notificationList');

    sendBtn.addEventListener('click', () => {
      sendForm.style.display = sendForm.style.display === 'none' ? 'block' : 'none';
      notificationList.style.display = 'none';
    });

    viewBtn.addEventListener('click', () => {
      notificationList.style.display = notificationList.style.display === 'none' ? 'block' : 'none';
      sendForm.style.display = 'none';
    });