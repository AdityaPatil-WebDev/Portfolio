const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

allSideMenu.forEach(item => {
    const li = item.parentElement;

    item.addEventListener('click', function () {
        allSideMenu.forEach(i => {
            i.parentElement.classList.remove('active');
        })
        li.classList.add('active');
    })
});

// TOGGLE SIDEBAR
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');

menuBar.addEventListener('click', function () {
    sidebar.classList.toggle('hide');
})

const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
const searchForm = document.querySelector('#content nav form');

searchButton.addEventListener('click', function (e) {
    if (window.innerWidth < 576) {
        e.preventDefault();
        searchForm.classList.toggle('show');
        if (searchForm.classList.contains('show')) {
            searchButtonIcon.classList.replace('bx-search', 'bx-x');
        } else {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
        }
    }
})

if (window.innerWidth < 768) {
    sidebar.classList.add('hide');
} else if (window.innerWidth > 576) {
    searchButtonIcon.classList.replace('bx-x', 'bx-search');
    searchForm.classList.remove('show');
}

window.addEventListener('resize', function () {
    if (this.innerWidth > 576) {
        searchButtonIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }
})

const switchMode = document.getElementById('switch-mode');

switchMode.addEventListener('change', function () {
    if (this.checked) {
        document.body.classList.add('dark');
    }
    else {
        document.body.classList.remove('dark');
    }
})

// Dropdown functionality
const dropdownToggles = document.querySelectorAll('.dropdown-toggle');

dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', function (e) {
        e.preventDefault(); // Prevent default anchor behavior
        const dropdownMenu = this.nextElementSibling; // Get the dropdown menu
        dropdownMenu.classList.toggle('show'); // Toggle the dropdown menu
    });
});

function showDashboard() {
    document.getElementById("dashboardSection").style.display = "block";
    document.getElementById("addHodSection").style.display = "none";
    document.getElementById("manageHodSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("meetingsSection").style.display = "none";
}

function showAddTeacher() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addHodSection").style.display = "block";
    document.getElementById("manageHodSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("meetingsSection").style.display = "none";
}

function showManageTeacher() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addHodSection").style.display = "none";
    document.getElementById("manageHodSection").style.display = "block";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("meetingsSection").style.display = "none";
}

function showAnnouncements() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addHodSection").style.display = "none";
    document.getElementById("manageHodSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "block";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("meetingsSection").style.display = "none";
}
function showMeetings() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addHodSection").style.display = "none";
    document.getElementById("manageHodSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("meetingsSection").style.display = "block";
    document.getElementById("settingsSection").style.display = "none";
}
// Function to show only the settings section
function showSettings() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addHodSection").style.display = "none";
    document.getElementById("manageHodSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "block";
    document.getElementById("meetingsSection").style.display = "none";
}

document.addEventListener("DOMContentLoaded", function () {
    // Show dashboard by default
    showDashboard();

    // Event listener for Dashboard button
    document.getElementById("dashboardBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showDashboard();
    });

    // Event listener for Add Teacher Staff button
    document.getElementById("addHodBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showAddTeacher();
    });

    // Event listener for Manage Teacher Staff button
    document.getElementById("manageHodBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showManageTeacher();
    });

    // ✅ Fixed Event Listener for announcement
    document.getElementById("announcementsBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showAnnouncements();
    });

    document.getElementById("meetingsBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showMeetings();
    });

    // ✅ Fixed Event Listener for settings
    document.getElementById("settingsBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showSettings(); // ✅ Corrected function call
    });

    

// settings
document.getElementById("updateDetailsForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const name = document.getElementById("updateName").value;
    const email = document.getElementById("updateEmail").value;

    fetch("/update_details", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name: name, email: email })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error("Error:", error);
        alert("An error occurred while updating details.");
    });
});

document.getElementById("changePasswordForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    fetch("/change_password", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ currentPassword, newPassword })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error("Error:", error);
        alert("An error occurred while changing password.");
    });
});
});

  
// hod reg manual
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("hodForm").addEventListener("submit", function(e) {
        e.preventDefault();

        const form = e.target;
        const formData = new FormData(form);

        fetch("/register_hod", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                alert("Registered Successfully!");
                form.reset();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            alert("Something went wrong!");
            console.error("Error:", error);
        });
    });
});


// send form data of meetings

document.addEventListener('DOMContentLoaded', function () {
    // Set today's date as the minimum selectable date in the date input
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('meetingDate').setAttribute('min', today);
});

document.getElementById('scheduleMeetingForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const topic = document.getElementById('meetingTopic').value;
    const rawDate = document.getElementById('meetingDate').value;
    const rawTime = document.getElementById('meetingTime').value;
    const message = document.getElementById('meetingMessage').value;
    const senderName = "Principal";

    // ❌ Date validation: prevent past dates
    const selectedDate = new Date(rawDate);
    const currentDate = new Date();
    selectedDate.setHours(0, 0, 0, 0);
    currentDate.setHours(0, 0, 0, 0);

    if (selectedDate < currentDate) {
        alert("Cannot schedule a meeting in the past. Please choose today or a future date.");
        return;
    }

    // ✅ Format date to DD-MM-YYYY
    const date = rawDate;

    const time = rawTime; // Send as "HH:MM" 24-hour format (e.g. "13:45")


    // ✅ Collect selected departments
    let departments = [];
    document.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => {
        if (cb.id === 'allDepts') {
            departments = ['BCA', 'BBA', 'BSC', 'BA', 'BCOM'];
        } else if (!departments.includes(cb.value.toUpperCase())) {
            departments.push(cb.value.toUpperCase());
        }
    });

    // ✅ Send data to backend
    fetch('/schedule_meeting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, date, time, message, sender_name: senderName, departments })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            alert('Meeting scheduled successfully!');
            document.getElementById('scheduleMeetingForm').reset();
            // Reset min attribute again after reset
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('meetingDate').setAttribute('min', today);
        } else {
            alert('Failed: ' + data.message);
        }
    })
    .catch(err => {
        console.error('Error:', err);
        alert('Something went wrong!');
    });
});

// dashboard

function fetchAndDisplay(category) {
    const urlMap = {
        'hods': '/view/hods',
        'teachers': '/view/teachers',
        'non_teaching': '/view/non_teaching',
        'students': '/view/students'
    };

    fetch(urlMap[category])
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('details-container');
            container.innerHTML = `<h3>${category.replace('_', ' ').toUpperCase()}</h3><ul></ul>`;
            const list = container.querySelector('ul');

            data.forEach(item => {
                let li = document.createElement('li');
                if (category === 'teachers' || category === 'hods') {
                    li.innerHTML = `<span class="username">${item.name}</span> | ${item.department} | ${item.subject}`;
                } else if (category === 'students') {
                    li.innerHTML = `<span class="username">${item.name}</span> | ${item.department} | Year: ${item.year}`;
                } else {
                    li.innerHTML = `<span class="username">${item.name}</span> | ${item.department}`;
                }
                
                list.appendChild(li);
            });
        })
        .catch(err => console.error('Error fetching data:', err));
}

// // upload
// function uploadHodExcel() {
//     var fileInput = document.getElementById('hodExcelUpload');
//     var file = fileInput.files[0];

//     if (!file) {
//         alert('Please select a file!');
//         return;
//     }

//     var formData = new FormData();
//     formData.append('file', file);

//     fetch('/upload_hod_excel', {
//         method: 'POST',
//         body: formData
//     })
//     .then(response => response.text())
//     .then(data => {
//         alert(data);
//         fileInput.value = '';
//     })
//     .catch(error => {
//         console.error('Error:', error);
//         alert('Error uploading file.');
//     });
// }

// manage hod
document.addEventListener('DOMContentLoaded', () => {
    const manageHodButton = document.getElementById('manageHodButton');
    const hodTableContainer = document.getElementById('hodTableContainer');

    manageHodButton.addEventListener('click', function () {
        document.getElementById('manageHodSection').classList.remove('hidden');
        hodTableContainer.classList.remove('hidden');  // Show table after click

        fetch('/get_hods')
            .then(response => response.json())
            .then(data => {
                const tbody = document.querySelector('#hodTable tbody');
                tbody.innerHTML = ''; // Clear old rows

                data.forEach(hod => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${hod.full_name}</td>
                        <td>${hod.email}</td>
                        <td>${hod.phone}</td>
                        <td>${hod.department}</td>
                        <td>
                            <button onclick="deleteHOD(${hod.id})">Delete</button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            })
            .catch(error => console.error('Error fetching HODs:', error));
    });
});


function deleteHOD(hodId) {
    if (confirm("Are you sure you want to delete this HOD?")) {
        fetch(`/delete_hod/${hodId}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                alert("HOD deleted successfully.");
                // Refresh the table
                document.getElementById('manageHodButton').click();
            } else {
                alert("Failed to delete HOD.");
            }
        })
        .catch(error => {
            console.error("Error deleting HOD:", error);
            alert("Error deleting HOD.");
        });
    }
}

