document.addEventListener("DOMContentLoaded", function () {
    const meetingsContainer = document.getElementById("meetingsList");
    if (!meetingsContainer) return;

    meetingsContainer.innerHTML = "<p>Loading meetings...</p>";

    fetch("/get_meetings")
        .then(response => {
            if (!response.ok) throw new Error("Network response was not ok");
            return response.json();
        })
        .then(data => {
            meetingsContainer.innerHTML = "";

            if (!data.meetings || data.meetings.length === 0) {
                meetingsContainer.innerHTML = "<p>No scheduled meetings.</p>";
                return;
            }

            function formatIndianDate(dateStr) {
                const [year, month, day] = dateStr.split("-");
                return `${day}/${month}/${year}`;
            }

            function formatTime12Hour(timeStr) {
                const [hour, minute] = timeStr.split(":");
                const h = parseInt(hour);
                const ampm = h >= 12 ? 'PM' : 'AM';
                const hour12 = h % 12 || 12;
                return `${hour12}:${minute} ${ampm}`;
            }

            data.meetings.forEach(meeting => {
                const meetingEl = document.createElement("div");
                meetingEl.className = "meeting-card";

                meetingEl.innerHTML = `
                    <h3>${meeting.topic}</h3>
                    <p><strong>Hi ${meeting.receiver_name},</strong> you have a scheduled meeting from <strong>${meeting.sender_name}</strong>.</p>
                    <p><strong>Date:</strong> ${formatIndianDate(meeting.date)}</p>
                    <p><strong>Time:</strong> ${formatTime12Hour(meeting.time)}</p>
                    <p><strong>Message:</strong> ${meeting.message}</p>
                    <p class="text-sm">Scheduled on: ${formatTimestampIST(meeting.timestamp)}</p>

                `;

                meetingsContainer.appendChild(meetingEl);
            });
        })
        .catch(error => {
            console.error("Error fetching meetings:", error);
            meetingsContainer.innerHTML = "<p class='text-red-600'>Failed to load meetings.</p>";
        });
});
