const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

allSideMenu.forEach(item => {
    const li = item.parentElement;

    item.addEventListener('click', function () {
        allSideMenu.forEach(i => {
            i.parentElement.classList.remove('active');
        })
        li.classList.add('active');
    })
});




// TOGGLE SIDEBAR
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');

menuBar.addEventListener('click', function () {
    sidebar.classList.toggle('hide');
})

const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
const searchForm = document.querySelector('#content nav form');

searchButton.addEventListener('click', function (e) {
    if (window.innerWidth < 576) {
        e.preventDefault();
        searchForm.classList.toggle('show');
        if (searchForm.classList.contains('show')) {
            searchButtonIcon.classList.replace('bx-search', 'bx-x');
        } else {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
        }
    }
})





if (window.innerWidth < 768) {
    sidebar.classList.add('hide');
} else if (window.innerWidth > 576) {
    searchButtonIcon.classList.replace('bx-x', 'bx-search');
    searchForm.classList.remove('show');
}


window.addEventListener('resize', function () {
    if (this.innerWidth > 576) {
        searchButtonIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }
})



const switchMode = document.getElementById('switch-mode');

switchMode.addEventListener('change', function () {
    if (this.checked) {
        document.body.classList.add('dark');
    }
    else {
        document.body.classList.remove('dark');
    }
})
// Dropdown functionality
document.querySelectorAll('.dropdown-toggle').forEach(item => {
	item.addEventListener('click', () => {
		const dropdown = item.nextElementSibling;
		dropdown.classList.toggle('active');
	});
});



// Function to show only the Dashboard section
function showDashboard() {
    document.getElementById("dashboardSection").style.display = "block";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}

// Function to show only the Add Teacher Staff section
function showAddTeacher() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "block";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}

// Function to show only the Manage Teacher Staff section
function showManageTeacher() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "block";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}

// Function to show only the Add Non-Teacher Staff section
function showAddNonTeacher() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "block";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}


// Function to show only the Manage Non-Teacher Staff section
function showManageNonTeacher() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "block";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}
// Function to show only the Add Student section
function showAddStudent() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "block";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}
// Function to show only the manage Student section
function showManageStudent() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "block";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}
function showAnnouncements() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "block";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}
function showNotifications() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "block";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}

function showMeetings() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "block";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "none";
}
function showSettings() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "block";
    document.getElementById("grievanceListSection").style.display = "none";
}
function showGrievance() {
    document.getElementById("dashboardSection").style.display = "none";
    document.getElementById("addTeacherSection").style.display = "none";
    document.getElementById("manageTeacherSection").style.display = "none";
    document.getElementById("addnonTeacherSection").style.display = "none";
    document.getElementById("managenonTeacherSection").style.display = "none";
    document.getElementById("addStudentSection").style.display = "none";
    document.getElementById("manageStudentSection").style.display = "none";
    document.getElementById("announcementsSection").style.display = "none";
    document.getElementById("notificationsSection").style.display = "none";
    document.getElementById("meetingsListSection").style.display = "none";
    document.getElementById("settingsSection").style.display = "none";
    document.getElementById("grievanceListSection").style.display = "block";
}

document.addEventListener("DOMContentLoaded", function () {
    // Show dashboard by default
    showDashboard();

    // Event listener for Dashboard button
    document.getElementById("dashboardBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showDashboard();
    });

    // Event listener for Add Teacher Staff button
    document.getElementById("addTeacherBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showAddTeacher();
    });

    // Event listener for Manage Teacher Staff button
    document.getElementById("manageTeacherBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showManageTeacher();
    });

    // ✅ Fixed Event Listener for Add Non-Teaching Staff
    document.getElementById("addnonTeacherBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showAddNonTeacher();
    });


    // ✅ Fixed Event Listener for Manage Non-Teaching Staff
    document.getElementById("managenonTeacherBtn").addEventListener("click", function (event) {
        event.preventDefault();
        showManageNonTeacher();
    });



// ✅ Fixed Event Listener for Add student
document.getElementById("addStudentBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showAddStudent();
});

// ✅ Fixed Event Listener for manage student
document.getElementById("manageStudentBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showManageStudent();
});

// ✅ Fixed Event Listener for announcement
document.getElementById("announcementsBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showAnnouncements();
});
// ✅ Fixed Event Listener for notifications
document.getElementById("notificationsBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showNotifications();
});

// Meetings
document.getElementById("meetingsBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showMeetings();
});

document.getElementById("grievanceBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showGrievance();
});

// Settings
document.getElementById("settingsBtn").addEventListener("click", function (event) {
    event.preventDefault();
    showSettings();
});
});

// message
document.addEventListener("DOMContentLoaded", function () {
    // Handle Send Announcement button click
    document.getElementById("sendAnnouncementBtn").addEventListener("click", function () {
        let announcementDiv = document.getElementById("announcementInputDiv");

        if (!announcementDiv) {
            announcementDiv = document.createElement("div");
            announcementDiv.id = "announcementInputDiv";
            announcementDiv.innerHTML = `
                <textarea id="announcementText" placeholder="Type your announcement here..." rows="4" style="width:100%; padding:8px; margin-top:10px;"></textarea>
                <button id="submitAnnouncement" style="margin-top:10px; padding:6px 12px;">Submit</button>
            `;
            document.getElementById("announcementsSection").appendChild(announcementDiv);

            document.getElementById("submitAnnouncement").addEventListener("click", function () {
                const text = document.getElementById("announcementText").value;
                if (text.trim() !== "") {
                    // Send to backend or show alert for now
                    alert("Announcement sent: " + text);
                    // Optionally clear textarea
                    document.getElementById("announcementText").value = "";
                } else {
                    alert("Please write an announcement before submitting.");
                }
            });
        }
    });



});

// settings

document.getElementById("updateDetailsForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const name = document.getElementById("updateName").value;
    const email = document.getElementById("updateEmail").value;

    fetch("/update_details", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({ name: name, email: email })
    })

        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while updating details.");
        });
});

document.getElementById("changePasswordForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    fetch("/change_password", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })

    })

        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while changing password.");
        });
});


document.addEventListener("DOMContentLoaded", function () {
    // Function to handle PDF upload
    function uploadPDF() {
        let formData = new FormData();
        let fileInput = document.getElementById("pdfUpload");
        console.log(fileInput.files); // Check if file is selected

        if (!fileInput.files.length) {
            alert("Please select a PDF file to upload.");
            return;
        }

        formData.append("file", fileInput.files[0]);

        fetch("/upload", {
            method: "POST",
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                let uploadResult = document.getElementById("uploadResult");
                if (data.teachers) {
                    let output = "<h3>Teacher Credentials</h3><ul>";
                    data.teachers.forEach(teacher => {
                        output += `<li>Email: <strong>${teacher.email}</strong> - Password: <strong>${teacher.password}</strong></li>`;
                    });
                    output += "</ul>";
                    uploadResult.innerHTML = output;
                } else {
                    uploadResult.innerHTML = "<p>Error uploading file. Please try again.</p>";
                }
            })
            .catch(error => console.error("Error:", error));
    }

    // Event Listener for PDF Upload Button
    document.getElementById("uploadPdfBtn").addEventListener("click", function (event) {
        event.preventDefault();
        uploadPDF();
    });
});

// upload pdf teacher
document.addEventListener("DOMContentLoaded", function () {
    function uploadPDF() {
        let formData = new FormData();
        let fileInput = document.getElementById("pdfUpload");

        if (!fileInput.files.length) {
            alert("Please select a PDF file to upload.");
            return;
        }

        formData.append("file", fileInput.files[0]);

        fetch("/upload", {
            method: "POST",
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                let uploadResult = document.getElementById("uploadResult");
                if (data.teachers) {
                    let output = "<h3>Teacher Credentials</h3><ul>";
                    data.teachers.forEach(teacher => {
                        output += `<li>Email: <strong>${teacher.email}</strong> - Password: <strong>${teacher.password}</strong></li>`;
                    });
                    output += "</ul>";
                    uploadResult.innerHTML = output;
                } else {
                    uploadResult.innerHTML = `<p>Error: ${data.error || "Something went wrong"}</p>`;
                }
            })
            .catch(error => console.error("Error:", error));
    }

    document.getElementById("uploadPdfBtn").addEventListener("click", function (event) {
        event.preventDefault();
        uploadPDF();
    });
});

// teachers manual registration

document.getElementById('teacherForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('/register_teacher', {
        method: 'POST',
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                alert("Registered Successfully!");
                form.reset();
            } else {
                alert(data.message);
            }
        })

        .catch(err => {
            alert('Something went wrong.');
            console.error(err);
        });
});

// non_teaching manual registration 
document.getElementById("nonTeacherForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch("/register_non_teaching", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                alert("Registered Successfully!");
                form.reset();
            } else {
                alert(data.message);
            }
        })

        .catch(err => {
            console.error("Error:", err);
            alert("Something went wrong. Please try again.");
        });
});


// student manual register
document.getElementById("studentForm").addEventListener("submit", function (e) {
    e.preventDefault();  // prevent default form submission

    const form = e.target;
    const formData = new FormData(form);

    fetch("/register_student", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                alert("Registered Successfully!");
                form.reset();
            } else {
                alert(data.message);
            }
        })

        .catch(error => {
            alert("Something went wrong!");
            console.error("Error:", error);
        });
});



// dashboard

function fetchAndDisplay(category) {
    const urlMap = {
        'hods': '/view/hods',
        'teachers': '/view/teachers',
        'non_teaching': '/view/non_teaching',
        'students': '/view/students'
    };

    fetch(urlMap[category])
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('details-container');
            container.innerHTML = `<h3>${category.replace('_', ' ').toUpperCase()}</h3><ul></ul>`;
            const list = container.querySelector('ul');

            data.forEach(item => {
                let li = document.createElement('li');
                if (category === 'teachers' || category === 'hods') {
                    li.textContent = `${item.name} | ${item.department} | ${item.subject}`;
                } else if (category === 'students') {
                    li.textContent = `${item.name} | ${item.department} | Year: ${item.year}`;
                } else {
                    li.textContent = `${item.name} | ${item.department}`;
                }
                list.appendChild(li);
            });
        })
        .catch(err => console.error('Error fetching data:', err));
}


// upload
function uploadTeachingExcel() {
    var fileInput = document.getElementById('teachingExcelUpload');
    var file = fileInput.files[0];

    if (!file) {
        alert('Please select a file!');
        return;
    }

    var formData = new FormData();
    formData.append('file', file);

    fetch('/upload_teaching_excel', {
        method: 'POST',
        body: formData
    })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fileInput.value = '';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error uploading file.');
        });
}

function uploadNonTeachingExcel() {
    var fileInput = document.getElementById('nonTeachingExcelUpload');
    var file = fileInput.files[0];

    if (!file) {
        alert('Please select a file!');
        return;
    }

    var formData = new FormData();
    formData.append('file', file);

    fetch('/upload_non_teaching_excel', {
        method: 'POST',
        body: formData
    })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fileInput.value = '';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error uploading file.');
        });
}

function uploadStudentExcel() {
    var fileInput = document.getElementById('studentExcelUpload');
    var file = fileInput.files[0];

    if (!file) {
        alert('Please select a file!');
        return;
    }

    var formData = new FormData();
    formData.append('file', file);

    fetch('/upload_student_excel', {
        method: 'POST',
        body: formData
    })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fileInput.value = '';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error uploading file.');
        });
}

// manage teacher
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('manageTeachingButton').addEventListener('click', () => {
        document.getElementById('teachingTableContainer').classList.remove('hidden');
        fetchDataAndPopulate('/get_teaching_staff', '#teachingTable tbody', ['full_name', 'email', 'phone', 'department', 'subject_specialization'], 'teaching');
    });
});

function fetchDataAndPopulate(url, tableSelector, fields, type) {
    fetch(url)
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector(tableSelector);
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                let cells = fields.map(f => `<td>${item[f]}</td>`).join('');
                row.innerHTML = `${cells}
                    <td><button class="delete-button" onclick="deleteItem(${item.id}, '${type}')">Delete</button></td>`;
                tbody.appendChild(row);
            });
        })
        .catch(err => console.error(`Error fetching ${type} data:`, err));
}

function deleteItem(id, type) {
    if (confirm(`Are you sure you want to delete this ${type.replace('_', ' ')}?`)) {
        fetch(`/delete_${type}/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert(`${type.replace('_', ' ')} deleted successfully.`);
                    document.getElementById(`manage${capitalize(type)}Button`).click();
                } else {
                    alert(`Failed to delete ${type.replace('_', ' ')}.`);
                }
            })
            .catch(error => {
                console.error(`Error deleting ${type}:`, error);
                alert(`Error deleting ${type}.`);
            });
    }
}

function capitalize(str) {
    return str.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
}


function capitalize(str) {
    return str.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
}
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('manageNonTeachingButton').addEventListener('click', () => {
        const section = document.getElementById('managenonTeacherSection');
        section.classList.remove('hidden');  // Show the manage section
        section.querySelector('#nonTeachingTable').style.display = 'table'; // Show the table

        fetchDataAndPopulate('/get_non_teaching_staff', '#nonTeachingTable tbody', ['full_name', 'email', 'phone', 'department'], 'non_teaching');
    });
});

function fetchDataAndPopulate(url, tableSelector, fields, type) {
    fetch(url)
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector(tableSelector);
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                let cells = fields.map(f => `<td>${item[f]}</td>`).join('');
                row.innerHTML = `${cells}
                    <td><button onclick="deleteItem(${item.id}, '${type}')">Delete</button></td>`;
                tbody.appendChild(row);
            });
        })
        .catch(err => console.error(`Error fetching ${type} data:`, err));
}

function deleteItem(id, type) {
    if (confirm(`Are you sure you want to delete this ${type.replace('_', ' ')}?`)) {
        fetch(`/delete_${type}/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert(`${type.replace('_', ' ')} deleted successfully.`);
                    document.getElementById(`manage${capitalize(type)}Button`).click();
                } else {
                    alert(`Failed to delete ${type.replace('_', ' ')}.`);
                }
            })
            .catch(error => {
                console.error(`Error deleting ${type}:`, error);
                alert(`Error deleting ${type}.`);
            });
    }
}

function capitalize(str) {
    return str.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' ');
}

// manage std
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('manageStudentButton').addEventListener('click', () => {
        document.getElementById('studentTableWrapper').classList.remove('hidden');
        fetchDataAndPopulate('/get_students', '#studentTable tbody', ['full_name', 'email', 'phone', 'roll_number', 'department', 'year'], 'student');
    });
});


function fetchDataAndPopulate(url, tableSelector, fields, type) {
    fetch(url)
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector(tableSelector);
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                let cells = fields.map(f => `<td>${item[f]}</td>`).join('');
                row.innerHTML = `${cells}
                    <td><button onclick="deleteItem(${item.id}, '${type}')">Delete</button></td>`;
                tbody.appendChild(row);
            });
        })
        .catch(err => console.error(`Error fetching ${type} data:`, err));
}

function deleteItem(id, type) {
    if (confirm(`Are you sure you want to delete this ${type.replace('_', ' ')}?`)) {
        fetch(`/delete_${type}/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert(`${type.replace('_', ' ')} deleted successfully.`);
                    document.getElementById(`manage${capitalize(type)}Button`).click();
                } else {
                    alert(`Failed to delete ${type.replace('_', ' ')}.`);
                }
            })
            .catch(error => {
                console.error(`Error deleting ${type}:`, error);
                alert(`Error deleting ${type}.`);
            });
    }
}

function capitalize(str) {
    return str.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
}

// notify
document.getElementById("viewNotificationBtn").addEventListener("click", function () {
    fetch('/view_notifications')
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length === 0) {
                html = "<p>No notifications found.</p>";
            } else {
                data.forEach(n => {
                    html += `<div class="notification-card">
								<strong>To:</strong> ${n.receiver} <br>
								<strong>From:</strong> ${n.sender} <br>
								<strong>Message:</strong> ${n.message} <br>
								<strong>Time:</strong> ${n.timestamp}
							 </div><hr>`;
                });

            }
            document.getElementById("notificationList").innerHTML = html;
        })
        .catch(error => {
            document.getElementById("notificationList").innerHTML = "<p>Error loading notifications.</p>";
            console.error("Error:", error);
        });
});

 const sendBtn = document.getElementById('sendNotificationBtn');
    const viewBtn = document.getElementById('viewNotificationBtn');
    const sendForm = document.getElementById('sendNotificationForm');
    const notificationList = document.getElementById('notificationList');

    sendBtn.addEventListener('click', () => {
      sendForm.style.display = sendForm.style.display === 'none' ? 'block' : 'none';
      notificationList.style.display = 'none';
    });

    viewBtn.addEventListener('click', () => {
      notificationList.style.display = notificationList.style.display === 'none' ? 'block' : 'none';
      sendForm.style.display = 'none';
    });