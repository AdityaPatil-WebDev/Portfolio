document.getElementById("sendNotificationBtn").addEventListener("click", () => {
  document.getElementById("sendNotificationForm").style.display = "block";
});

document.getElementById("moduleSelect").addEventListener("change", function () {
  const module = this.value;
  const userCheckboxes = document.getElementById("userCheckboxes");
  userCheckboxes.innerHTML = "Loading...";

  if (module) {
    fetch(`/get-users/${module}`)
      .then(response => response.json())
      .then(data => {
        userCheckboxes.innerHTML = "";

        if (data.length === 0) {
          userCheckboxes.innerHTML = "<p>No users found.</p>";
        } else {
          data.forEach(user => {
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.name = "user_ids";
            checkbox.value = user.id;

            const label = document.createElement("label");
            label.textContent = `${user.name} (${user.email})`;

            const div = document.createElement("div");
            div.appendChild(checkbox);
            div.appendChild(label);
            userCheckboxes.appendChild(div);
          });
        }
      });
  }
});

document.getElementById("notificationForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const module = document.getElementById("moduleSelect").value;
  const message = document.getElementById("message").value;
  const userIds = [...document.querySelectorAll("input[name='user_ids']:checked")].map(cb => cb.value);

  if (userIds.length === 0) {
    alert("Please select at least one user.");
    return;
  }

  fetch("/send-notification", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ module, userIds, message })
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    document.getElementById("notificationForm").reset();
    document.getElementById("userCheckboxes").innerHTML = "";
    document.getElementById("sendNotificationForm").style.display = "none";
  });
});
