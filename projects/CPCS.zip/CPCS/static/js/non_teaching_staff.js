document.addEventListener("DOMContentLoaded", function () {
    // Sidebar Menu Active State
    const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');
    allSideMenu.forEach(item => {
        const li = item.parentElement;
        item.addEventListener('click', function (e) {
            e.preventDefault(); // Prevent default anchor behavior
            allSideMenu.forEach(i => i.parentElement.classList.remove('active'));
            li.classList.add('active');
        });
    });

    // Section Buttons
    const sectionButtons = {
        dashboardBtn: 'dashboardSection',
        announcementsBtn: 'announcementsSection',
        notificationsBtn: 'notificationsSection',
        addStudentBtn: 'addStudentSection',
        manageStudentBtn: 'manageStudentSection',
        grievanceBtn: 'grievanceListSection',
        settingsBtn: 'settingsSection'
    };

    // Hide all sections
    function hideAllSections() {
        Object.values(sectionButtons).forEach(id => {
            const section = document.getElementById(id);
            if (section) section.style.display = 'none';
        });
    }

    // Attach event listeners to buttons
    Object.keys(sectionButtons).forEach(btnId => {
        const button = document.getElementById(btnId);
        const sectionId = sectionButtons[btnId];
        if (button && sectionId) {
            button.addEventListener('click', () => {
                hideAllSections();
                const section = document.getElementById(sectionId);
                if (section) section.style.display = 'block';
            });
        }
    });

    // Show dashboard section by default
    hideAllSections();
    document.getElementById('dashboardSection').style.display = 'block';
});


    // Dark Mode Toggle
    const switchMode = document.getElementById('switch-mode');
    switchMode?.addEventListener('change', function () {
        document.body.classList.toggle('dark', this.checked);
    });

    // Dropdown Toggle
    document.querySelectorAll(".dropdown-toggle").forEach(toggle => {
        toggle.addEventListener("click", function (e) {
            e.preventDefault();
            const dropdownMenu = this.nextElementSibling;
            dropdownMenu?.classList.toggle('show');
        });
    });

    
// student manual register
document.getElementById("studentForm").addEventListener("submit", function(e) {
    e.preventDefault();  // prevent default form submission

    const form = e.target;
    const formData = new FormData(form);

    fetch("/register_student", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            alert("Registered Successfully!");
            form.reset(); 
        } else {
            alert(data.message);
        }
    })
    
    .catch(error => {
        alert("Something went wrong!");
        console.error("Error:", error);
    });
});



// upload
function uploadStudentExcel() {
    var fileInput = document.getElementById('studentExcelUpload');
    var file = fileInput.files[0];

    if (!file) {
        alert('Please select a file!');
        return;
    }

    var formData = new FormData();
    formData.append('file', file);

    fetch('/upload_student_excel', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        fileInput.value = '';
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error uploading file.');
    });
}

// dashboard

function fetchAndDisplay(category) {
    const urlMap = {
        'hods': '/view/hods',
        'teachers': '/view/teachers',
        'non_teaching': '/view/non_teaching',
        'students': '/view/students'
    };

    fetch(urlMap[category])
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('details-container');
            container.innerHTML = `<h3>${category.replace('_', ' ').toUpperCase()}</h3><ul></ul>`;
            const list = container.querySelector('ul');

            data.forEach(item => {
                let li = document.createElement('li');
                if (category === 'teachers' || category === 'hods') {
                    li.textContent = `${item.name} | ${item.department} | ${item.subject}`;
                } else if (category === 'students') {
                    li.textContent = `${item.name} | ${item.department} | Year: ${item.year}`;
                } else {
                    li.textContent = `${item.name} | ${item.department}`;
                }
                list.appendChild(li);
            });
        })
        .catch(err => console.error('Error fetching data:', err));
}

    // settings
    
    document.getElementById("updateDetailsForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("updateName").value;
        const email = document.getElementById("updateEmail").value;
    
        fetch("/update_details", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include", 
            body: JSON.stringify({ name: name, email: email })
        })
        
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while updating details.");
        });
    });
    
    document.getElementById("changePasswordForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const currentPassword = document.getElementById("currentPassword").value;
        const newPassword = document.getElementById("newPassword").value;
        const confirmPassword = document.getElementById("confirmPassword").value;
    
        if (newPassword !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }
    
        fetch("/change_password", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",  
            body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })

        })
        
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred while changing password.");
        });
    });

// notify
document.getElementById("viewNotificationBtn").addEventListener("click", function () {
    fetch('/view_notifications')
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length === 0) {
                html = "<p>No notifications found.</p>";
            } else {
                data.forEach(n => {
					html += `<div class="notification-card">
								<strong>To:</strong> ${n.receiver} <br>
								<strong>From:</strong> ${n.sender} <br>
								<strong>Message:</strong> ${n.message} <br>
								<strong>Time:</strong> ${n.timestamp}
							 </div><hr>`;
				});
				
            }
            document.getElementById("notificationList").innerHTML = html;
        })
        .catch(error => {
            document.getElementById("notificationList").innerHTML = "<p>Error loading notifications.</p>";
            console.error("Error:", error);
        });
});



// manage std
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('manageStudentButton').addEventListener('click', () => {
        document.getElementById('studentTableWrapper').classList.remove('hidden');
        fetchDataAndPopulate('/get_students', '#studentTable tbody', ['full_name', 'email', 'phone', 'roll_number', 'department', 'year'], 'student');
    });
});


function fetchDataAndPopulate(url, tableSelector, fields, type) {
    fetch(url)
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector(tableSelector);
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                let cells = fields.map(f => `<td>${item[f]}</td>`).join('');
                row.innerHTML = `${cells}
                    <td><button onclick="deleteItem(${item.id}, '${type}')">Delete</button></td>`;
                tbody.appendChild(row);
            });
        })
        .catch(err => console.error(`Error fetching ${type} data:`, err));
}

function deleteItem(id, type) {
    if (confirm(`Are you sure you want to delete this ${type.replace('_', ' ')}?`)) {
        fetch(`/delete_${type}/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert(`${type.replace('_', ' ')} deleted successfully.`);
                    document.getElementById(`manage${capitalize(type)}Button`).click();
                } else {
                    alert(`Failed to delete ${type.replace('_', ' ')}.`);
                }
            })
            .catch(error => {
                console.error(`Error deleting ${type}:`, error);
                alert(`Error deleting ${type}.`);
            });
    }
}

function capitalize(str) {
    return str.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
}

 const sendBtn = document.getElementById('sendNotificationBtn');
    const viewBtn = document.getElementById('viewNotificationBtn');
    const sendForm = document.getElementById('sendNotificationForm');
    const notificationList = document.getElementById('notificationList');

    sendBtn.addEventListener('click', () => {
      sendForm.style.display = sendForm.style.display === 'none' ? 'block' : 'none';
      notificationList.style.display = 'none';
    });

    viewBtn.addEventListener('click', () => {
      notificationList.style.display = notificationList.style.display === 'none' ? 'block' : 'none';
      sendForm.style.display = 'none';
    });