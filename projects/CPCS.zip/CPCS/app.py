from flask import Flask
from flask_session import Session
from extensions import db, mysql
from routes import routes, announcement_bp, settings_bp, meeting_bp, grievance_bp, admin_bp

def create_app():
    app = Flask(__name__)
    app.secret_key = 'asqgsasgagsagsagsgasgag'

    # MySQL & SQLAlchemy configuration
    app.config['MYSQL_HOST'] = 'localhost'
    app.config['MYSQL_USER'] = 'root'
    app.config['MYSQL_PASSWORD'] = ''
    app.config['MYSQL_DB'] = 'cpcs'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/cpcs'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Session configuration
    app.config['SESSION_TYPE'] = 'filesystem'  
    app.config['SESSION_PERMANENT'] = False
    Session(app) 
    mysql.init_app(app)
    db.init_app(app)

    app.register_blueprint(routes)
    app.register_blueprint(announcement_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(meeting_bp)
    app.register_blueprint(grievance_bp)
    app.register_blueprint(admin_bp)

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
