# extensions.py holds shared db and mysql objects.No circular imports anymore

from flask_sqlalchemy import SQLAlchemy
from flask_mysqldb import MySQL

db = SQLAlchemy()
mysql = MySQL()
